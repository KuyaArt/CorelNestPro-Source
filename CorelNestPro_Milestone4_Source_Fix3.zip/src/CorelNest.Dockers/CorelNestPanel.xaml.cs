using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows;
using System.Windows.Controls;

namespace CorelNest.Dockers;

/// <summary>Public parameterless WPF control loaded by CorelDRAW FrameWork.AddDocker.</summary>
public partial class CorelNestPanel : UserControl
{
    private const int MillimeterUnit = 3;
    private const string ProgId = "CorelDRAW.Application.27";
    private string? _placementFile;
    private int _selectionCount;
    private int _placedCount;
    private List<string>? _selectionFingerprint;
    private double _sheetWidth;
    private double _sheetHeight;
    private double _borderGap;

    public CorelNestPanel()
    {
        InitializeComponent();
    }

    private void PreviewButton_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            PreviewButton.IsEnabled = false;
            ApplyButton.IsEnabled = false;
            StatusText.Text = "Membaca geometri dan menghitung nesting…";
            ValidateInputs();
            dynamic app = GetCorel();
            dynamic selection = app.ActiveSelectionRange;
            _selectionCount = Convert.ToInt32(selection.Count, CultureInfo.InvariantCulture);
            if (_selectionCount < 1) throw new InvalidOperationException("Pilih satu atau beberapa objek terlebih dahulu.");
            _selectionFingerprint = CaptureSelectionFingerprint(app, selection);

            string root = Path.GetDirectoryName(typeof(CorelNestPanel).Assembly.Location) ?? AppDomain.CurrentDomain.BaseDirectory;
            string engineDirectory = Path.Combine(root, "Engine");
            string runner = Path.Combine(engineDirectory, "CorelNest.Export.exe");
            if (!File.Exists(runner)) throw new FileNotFoundException("Mesin nesting tidak ditemukan. Jalankan installer/build package CorelNest Pro.", runner);
            _placementFile = Path.Combine(Path.GetTempPath(), "CorelNest_M4_" + Guid.NewGuid().ToString("N") + ".csv");

            var args = new StringBuilder();
            AddArg(args, "--nest-selection", _placementFile);
            AddArg(args, "--sheet-width-mm", F(_sheetWidth));
            AddArg(args, "--sheet-height-mm", F(_sheetHeight));
            AddArg(args, "--part-gap-mm", F(ReadNumber(PartGapBox, "Jarak antarobjek")));
            AddArg(args, "--border-gap-mm", F(_borderGap));
            AddArg(args, "--rotation-step-deg", F(ReadNumber(RotationBox, "Langkah rotasi")));
            AddArg(args, "--tolerance-mm", F(ReadNumber(ToleranceBox, "Toleransi kurva")));
            AddArg(args, "--prog-id", ProgId);

            var psi = new ProcessStartInfo(runner, args.ToString())
            {
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                WorkingDirectory = engineDirectory
            };
            using (var process = Process.Start(psi) ?? throw new InvalidOperationException("Gagal menjalankan mesin nesting."))
            {
                string stdout = process.StandardOutput.ReadToEnd();
                string stderr = process.StandardError.ReadToEnd();
                process.WaitForExit();
                if (process.ExitCode != 0)
                    throw new InvalidOperationException(string.IsNullOrWhiteSpace(stderr) ? stdout : stderr);
                _placedCount = ReadMetric(stdout, "NEST_OK");
                int unplaced = ReadMetric(stdout, "NEST_UNPLACED");
                double utilization = ReadMetricDouble(stdout, "NEST_UTILIZATION");
                if (!File.Exists(_placementFile)) throw new InvalidOperationException("File hasil nesting tidak ditemukan.");
                int rows = ReadPlacements(_placementFile).Count;
                if (rows != _placedCount) throw new InvalidDataException("Jumlah baris hasil tidak cocok dengan ringkasan mesin nesting.");
                SummaryText.Text = $"Objek terpilih: {_selectionCount}\nBerhasil ditempatkan: {_placedCount}\nTidak muat: {unplaced}\nPemakaian material: {utilization.ToString("0.00", CultureInfo.InvariantCulture)}%\nArea material: {_sheetWidth:0.##} × {_sheetHeight:0.##} mm";
                StatusText.Text = unplaced > 0 ? "Pratinjau selesai. Sebagian objek tidak muat; periksa hasil sebelum menerapkan." : "Pratinjau siap diterapkan ke halaman aktif.";
                ApplyButton.IsEnabled = _placedCount > 0;
            }
        }
        catch (Exception ex)
        {
            SummaryText.Text = "Analisis gagal.";
            StatusText.Text = ex.Message;
            MessageBox.Show(ex.Message, "CorelNest Pro", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
        finally { PreviewButton.IsEnabled = true; }
    }

    private void ApplyButton_Click(object sender, RoutedEventArgs e)
    {
        if (string.IsNullOrWhiteSpace(_placementFile) || !File.Exists(_placementFile))
        {
            ApplyButton.IsEnabled = false;
            StatusText.Text = "Pratinjau sudah tidak tersedia. Jalankan analisis kembali.";
            return;
        }

        dynamic? app = null;
        dynamic? document = null;
        int oldUnit = MillimeterUnit;
        bool commandOpen = false;
        try
        {
            var placements = ReadPlacements(_placementFile);
            if (placements.Count == 0) throw new InvalidDataException("Tidak ada placement untuk diterapkan.");
            app = GetCorel();
            document = app.ActiveDocument;
            dynamic selection = app.ActiveSelectionRange;
            int count = Convert.ToInt32(selection.Count, CultureInfo.InvariantCulture);
            List<string> currentFingerprint = CaptureSelectionFingerprint(app, selection);
            bool sameSelection = _selectionFingerprint != null &&
                Enumerable.SequenceEqual<string>(_selectionFingerprint, currentFingerprint, StringComparer.Ordinal);
            if (count != _selectionCount || !sameSelection)
                throw new InvalidOperationException("Dokumen atau pilihan objek berubah setelah pratinjau. Pilih kembali objek yang sama lalu jalankan analisis ulang.");
            foreach (var p in placements)
                if (p.SelectionIndex < 1 || p.SelectionIndex > count) throw new InvalidDataException("Index objek pada hasil nesting tidak valid.");
            var originalShapes = new object[count];
            for (int i = 1; i <= count; i++) originalShapes[i - 1] = selection.Item(i);

            oldUnit = Convert.ToInt32(document.Unit, CultureInfo.InvariantCulture);
            document.Unit = MillimeterUnit;
            app.BeginCommandGroup("CorelNest Pro - Apply Nesting");
            commandOpen = true;
            foreach (var p in placements)
            {
                dynamic source = originalShapes[p.SelectionIndex - 1];
                dynamic copy = source.Duplicate(0.0, 0.0);
                if (Math.Abs(p.RotationDegrees) > 1e-8) copy.Rotate(p.RotationDegrees);
                double x = 0, y = 0, width = 0, height = 0;
                copy.GetBoundingBox(out x, out y, out width, out height, false);
                // NestingEngine already includes BorderGap in the returned coordinates.
                double targetX = p.Xmm;
                double targetY = p.Ymm;
                copy.Move(targetX - x, targetY - y);
            }
            app.EndCommandGroup();
            commandOpen = false;
            document.Unit = oldUnit;
            ApplyButton.IsEnabled = false;
            StatusText.Text = $"Berhasil membuat {_placedCount} salinan hasil nesting. Objek sumber tetap dipertahankan.";
            MessageBox.Show($"Nesting diterapkan.\nSalinan dibuat: {_placedCount}\nObjek sumber tidak dipindahkan atau dihapus.", "CorelNest Pro", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex)
        {
            try { if (commandOpen && app != null) app.EndCommandGroup(); } catch { }
            try { if (document != null) document.Unit = oldUnit; } catch { }
            StatusText.Text = "Penerapan gagal: " + ex.Message;
            MessageBox.Show("Penerapan layout gagal. Jika ada perubahan parsial, gunakan Undo di CorelDRAW.\n\n" + ex.Message,
                "CorelNest Pro", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void ValidateInputs()
    {
        _sheetWidth = ReadNumber(SheetWidthBox, "Lebar material");
        _sheetHeight = ReadNumber(SheetHeightBox, "Tinggi material");
        _borderGap = ReadNumber(BorderGapBox, "Margin tepi");
        double gap = ReadNumber(PartGapBox, "Jarak antarobjek");
        double rotation = ReadNumber(RotationBox, "Langkah rotasi");
        double tolerance = ReadNumber(ToleranceBox, "Toleransi kurva");
        if (_sheetWidth <= 0 || _sheetHeight <= 0) throw new ArgumentException("Ukuran material harus lebih besar dari nol.");
        if (_borderGap < 0 || gap < 0) throw new ArgumentException("Jarak dan margin tidak boleh negatif.");
        if (_sheetWidth <= 2 * _borderGap || _sheetHeight <= 2 * _borderGap) throw new ArgumentException("Margin terlalu besar untuk ukuran material.");
        if (rotation <= 0 || rotation > 360) throw new ArgumentException("Langkah rotasi harus di antara 0 dan 360 derajat.");
        if (tolerance <= 0 || tolerance > 5) throw new ArgumentException("Toleransi kurva harus di antara 0 dan 5 mm.");
    }

    private static List<string> CaptureSelectionFingerprint(dynamic app, dynamic selection)
    {
        dynamic document = app.ActiveDocument;
        int oldUnit = Convert.ToInt32(document.Unit, CultureInfo.InvariantCulture);
        var values = new List<string>();
        try
        {
            document.Unit = MillimeterUnit;
            string docName = "";
            string docPath = "";
            try { docName = Convert.ToString(document.Name) ?? ""; } catch { }
            try { docPath = Convert.ToString(document.FullFileName) ?? ""; } catch { }
            values.Add(docName + "|" + docPath);
            int count = Convert.ToInt32(selection.Count, CultureInfo.InvariantCulture);
            for (int i = 1; i <= count; i++)
            {
                dynamic shape = selection.Item(i);
                string name = "";
                try { name = Convert.ToString(shape.Name) ?? ""; } catch { }
                double x = 0, y = 0, w = 0, h = 0;
                shape.GetBoundingBox(out x, out y, out w, out h, false);
                values.Add(name + "|" + F(x) + "|" + F(y) + "|" + F(w) + "|" + F(h));
            }
        }
        finally { document.Unit = oldUnit; }
        return values;
    }

    private static double ReadNumber(TextBox box, string label)
    {
        if (!double.TryParse(box.Text.Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out double value) &&
            !double.TryParse(box.Text.Trim(), NumberStyles.Float, CultureInfo.CurrentCulture, out value))
            throw new ArgumentException(label + " harus berupa angka.");
        if (double.IsNaN(value) || double.IsInfinity(value)) throw new ArgumentException(label + " tidak valid.");
        return value;
    }

    private static string F(double value) => value.ToString("0.########", CultureInfo.InvariantCulture);
    private static void AddArg(StringBuilder b, string key, string value) => b.Append('"').Append(key).Append('"').Append(' ').Append('"').Append(value.Replace("\"", "\\\"")).Append('"').Append(' ');

    private static dynamic GetCorel()
    {
        if (!OperatingSystemCheck.IsWindows) throw new PlatformNotSupportedException("CorelNest Docker hanya berjalan di Windows.");
        Type? type = Type.GetTypeFromProgID(ProgId);
        if (type == null) throw new InvalidOperationException("CorelDRAW 27 tidak ditemukan. Buka CorelDRAW Technical Suite terlebih dahulu.");
        try { return Marshal.GetActiveObject(ProgId); }
        catch (COMException) { throw new InvalidOperationException("CorelDRAW belum berjalan. Buka CorelDRAW dan dokumen terlebih dahulu."); }
    }

    private static int ReadMetric(string output, string key)
    {
        string? line = output.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries).FirstOrDefault(x => x.StartsWith(key + "=", StringComparison.Ordinal));
        return line != null && int.TryParse(line.Substring(key.Length + 1), NumberStyles.Integer, CultureInfo.InvariantCulture, out int n) ? n : 0;
    }

    private static double ReadMetricDouble(string output, string key)
    {
        string? line = output.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries).FirstOrDefault(x => x.StartsWith(key + "=", StringComparison.Ordinal));
        return line != null && double.TryParse(line.Substring(key.Length + 1), NumberStyles.Float, CultureInfo.InvariantCulture, out double n) ? n : 0;
    }

    private static List<PlacementRow> ReadPlacements(string path)
    {
        var rows = new List<PlacementRow>();
        foreach (string line in File.ReadAllLines(path).Skip(1))
        {
            if (string.IsNullOrWhiteSpace(line)) continue;
            string[] c = line.Split(',');
            if (c.Length != 7) throw new InvalidDataException("Format CSV hasil nesting tidak valid.");
            rows.Add(new PlacementRow(
                int.Parse(c[0], CultureInfo.InvariantCulture), int.Parse(c[1], CultureInfo.InvariantCulture),
                double.Parse(c[2], CultureInfo.InvariantCulture), double.Parse(c[3], CultureInfo.InvariantCulture),
                double.Parse(c[4], CultureInfo.InvariantCulture), double.Parse(c[5], CultureInfo.InvariantCulture),
                double.Parse(c[6], CultureInfo.InvariantCulture)));
        }
        return rows;
    }

    private sealed class PlacementRow
    {
        public int SelectionIndex { get; }
        public int CopyIndex { get; }
        public double Xmm { get; }
        public double Ymm { get; }
        public double RotationDegrees { get; }
        public double WidthMm { get; }
        public double HeightMm { get; }
        public PlacementRow(int selectionIndex, int copyIndex, double x, double y, double rotation, double width, double height)
        { SelectionIndex = selectionIndex; CopyIndex = copyIndex; Xmm = x; Ymm = y; RotationDegrees = rotation; WidthMm = width; HeightMm = height; }
    }
}

internal static class OperatingSystemCheck
{
    public static bool IsWindows => Environment.OSVersion.Platform == PlatformID.Win32NT;
}
