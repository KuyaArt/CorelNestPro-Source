[CmdletBinding()]
param(
    [string]$Configuration = 'Release',
    [string]$Runtime = 'win-x64'
)
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$artifacts = Join-Path $root 'artifacts'
$package = Join-Path $artifacts 'CorelNestPro-Milestone4'
$exportProject = Join-Path $root 'src\CorelNest.Export\CorelNest.Export.csproj'
$dockerProject = Join-Path $root 'src\CorelNest.Dockers\CorelNest.Dockers.csproj'

if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) { throw '.NET SDK tidak ditemukan. Instal .NET 8 SDK dan .NET Framework 4.8 Developer Pack.' }
if (Test-Path $package) { Remove-Item $package -Recurse -Force }
New-Item $package -ItemType Directory -Force | Out-Null

Write-Host '[1/4] Menjalankan regression test geometri…' -ForegroundColor Cyan
dotnet run --project (Join-Path $root 'tests\CorelNest.Geometry.Tests\CorelNest.Geometry.Tests.csproj') -c $Configuration
if ($LASTEXITCODE -ne 0) { throw 'Regression test geometri gagal.' }

Write-Host '[2/4] Build mesin exporter + nesting (self-contained win-x64)…' -ForegroundColor Cyan
dotnet publish $exportProject -c $Configuration -r $Runtime --self-contained true `
  -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true `
  -p:PublishTrimmed=false -p:DebugType=None -p:DebugSymbols=false -o (Join-Path $package 'Engine')
if ($LASTEXITCODE -ne 0) { throw 'Publish mesin nesting gagal.' }

Write-Host '[3/4] Build Docker WPF .NET Framework 4.8…' -ForegroundColor Cyan
dotnet build $dockerProject -c $Configuration
if ($LASTEXITCODE -ne 0) { throw 'Build Docker WPF gagal. Pastikan .NET Framework 4.8 Developer Pack tersedia.' }
$dockerDll = Join-Path $root "src\CorelNest.Dockers\bin\$Configuration\net48\CorelNest.Dockers.dll"
if (-not (Test-Path $dockerDll)) { throw "Assembly Docker tidak ditemukan: $dockerDll" }
Copy-Item $dockerDll (Join-Path $package 'CorelNest.Dockers.dll') -Force

Write-Host '[4/4] Menyiapkan installer dan dokumentasi…' -ForegroundColor Cyan
Copy-Item (Join-Path $root 'installer\Install-CorelNest.ps1') $package -Force
Copy-Item (Join-Path $root 'installer\Uninstall-CorelNest.ps1') $package -Force
Copy-Item (Join-Path $root 'installer\Install-CorelNest.bat') $package -Force
Copy-Item (Join-Path $root 'installer\Uninstall-CorelNest.bat') $package -Force
Copy-Item (Join-Path $root 'README_MILESTONE4.md') $package -Force
$zip = Join-Path $artifacts 'CorelNestPro-Milestone4-Windows-x64.zip'
if (Test-Path $zip) { Remove-Item $zip -Force }
Compress-Archive -Path (Join-Path $package '*') -DestinationPath $zip -CompressionLevel Optimal
Write-Host "Selesai: $zip" -ForegroundColor Green
$issc = Get-Command 'ISCC.exe' -ErrorAction SilentlyContinue
if (-not $issc) {
    $candidate = Join-Path ${env:ProgramFiles(x86)} 'Inno Setup 6\ISCC.exe'
    if (Test-Path $candidate) { $issc = [pscustomobject]@{ Source = $candidate } }
}
if (-not $issc) {
    $candidate = Join-Path $env:ProgramFiles 'Inno Setup 6\ISCC.exe'
    if (Test-Path $candidate) { $issc = [pscustomobject]@{ Source = $candidate } }
}
if ($issc) {
    $iss = Join-Path $root 'installer\CorelNestPro.iss'
    & $issc.Source $iss "/DSourceDir=`"$package`"" "/DOutputDir=`"$artifacts`""
    if ($LASTEXITCODE -ne 0) { throw 'Kompilasi installer Inno Setup gagal.' }
    Write-Host "Installer EXE dibuat di folder: $artifacts" -ForegroundColor Green
} else {
    Write-Host 'ISCC.exe tidak ditemukan; paket ZIP tetap tersedia. Pasang Inno Setup lalu kompilasi installer\CorelNestPro.iss jika membutuhkan Setup.exe.' -ForegroundColor Yellow
}
Write-Host 'Ekstrak ZIP, lalu jalankan Install-CorelNest.bat. CorelDRAW harus terbuka.'
