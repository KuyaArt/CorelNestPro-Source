# CorelNest Pro

CorelDRAW-integrated vector nesting project for Windows x64.

- Milestone 1: polygon geometry and initial nesting.
- Milestone 2: CorelDRAW COM selection export and adaptive curve flattening.
- Milestone 3: compound contour topology, explicit holes and hole-aware placement (including Fix1 clearance-boundary regression fix).
- Milestone 4: native WPF Docker panel, selection-to-nesting pipeline, preview summary and apply-layout duplicate workflow.

See `README_MILESTONE3.md` and `README_MILESTONE4.md` for implementation details and known limitations.
