Attribute VB_Name = "CorelNestBridge"
Option Explicit

' Milestone 2 launcher. Edit CN_EXPORT_EXE after building the .NET exporter.
Private Const CN_EXPORT_EXE As String = "C:\CorelNestPro\publish\CorelNest.Export.exe"

Public Sub CN_ExportSelectedGeometry()
    Dim outputFile As String
    Dim commandLine As String
    Dim shell As Object
    Dim exitCode As Long

    If ActiveDocument Is Nothing Then
        MsgBox "Buka dokumen CorelDRAW terlebih dahulu.", vbExclamation, "CorelNest"
        Exit Sub
    End If

    If ActiveSelectionRange.Count = 0 Then
        MsgBox "Pilih satu atau beberapa objek terlebih dahulu.", vbExclamation, "CorelNest"
        Exit Sub
    End If

    If Dir$(CN_EXPORT_EXE) = vbNullString Then
        MsgBox "Exporter tidak ditemukan:" & vbCrLf & CN_EXPORT_EXE & vbCrLf & _
               "Build dan publish proyek CorelNest.Export terlebih dahulu.", vbCritical, "CorelNest"
        Exit Sub
    End If

    outputFile = Environ$("TEMP") & "\CorelNest_selection.json"
    commandLine = """" & CN_EXPORT_EXE & """ --export-selection """ & outputFile & """ --tolerance-mm 0.20"

    Set shell = CreateObject("WScript.Shell")
    exitCode = shell.Run(commandLine, 1, True)

    If exitCode <> 0 Or Dir$(outputFile) = vbNullString Then
        MsgBox "Ekspor geometri gagal. Exit code: " & CStr(exitCode) & vbCrLf & _
               "Periksa pesan pada jendela exporter.", vbCritical, "CorelNest"
        Exit Sub
    End If

    MsgBox "Geometri berhasil diekspor:" & vbCrLf & outputFile, vbInformation, "CorelNest"
End Sub
