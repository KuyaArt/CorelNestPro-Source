[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'
$dockerGuid = '{E4B80B0C-42F1-4C2A-9F62-4D9A0F8C8B31}'
try { $app = [Runtime.InteropServices.Marshal]::GetActiveObject('CorelDRAW.Application.27') }
catch { Write-Host 'CorelDRAW tidak sedang berjalan; tidak ada Docker aktif untuk dilepas.'; exit 0 }
try { $app.FrameWork.HideDocker($dockerGuid) } catch { }
try { $app.FrameWork.RemoveDocker($dockerGuid) } catch { }
Write-Host 'CorelNest Pro dilepas dari sesi CorelDRAW saat ini.' -ForegroundColor Green
