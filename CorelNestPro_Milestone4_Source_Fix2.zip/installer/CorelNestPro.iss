#define AppName "CorelNest Pro"
#define AppVersion "0.4.0"
#ifndef SourceDir
  #define SourceDir "..\artifacts\CorelNestPro-Milestone4"
#endif
#ifndef OutputDir
  #define OutputDir "..\artifacts"
#endif

[Setup]
AppId={{9D5B4E6B-1C22-4F83-8B8E-7E2F6B6F1A40}
AppName={#AppName}
AppVersion={#AppVersion}
AppPublisher=CorelNest Pro
DefaultDirName={localappdata}\Programs\CorelNestPro
DefaultGroupName=CorelNest Pro
PrivilegesRequired=lowest
ArchitecturesInstallIn64BitMode=x64
ArchitecturesAllowed=x64
OutputDir={#OutputDir}
OutputBaseFilename=CorelNestPro-Setup-{#AppVersion}-x64
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
UninstallDisplayIcon={app}\CorelNest.Dockers.dll

[Files]
Source: "{#SourceDir}\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{group}\CorelNest Pro - Install Docker"; Filename: "{app}\Install-CorelNest.bat"
Name: "{group}\CorelNest Pro - Uninstall Docker"; Filename: "{app}\Uninstall-CorelNest.bat"
Name: "{commondesktop}\CorelNest Pro"; Filename: "{app}\Install-CorelNest.bat"; Tasks: desktopicon

[Tasks]
Name: "desktopicon"; Description: "Buat shortcut di Desktop"; GroupDescription: "Shortcut tambahan:"; Flags: unchecked

[Run]
Filename: "powershell.exe"; Parameters: "-NoProfile -ExecutionPolicy Bypass -File ""{app}\Install-CorelNest.ps1"""; Description: "Muat Docker CorelNest Pro ke CorelDRAW"; Flags: postinstall nowait skipifsilent

[UninstallRun]
Filename: "powershell.exe"; Parameters: "-NoProfile -ExecutionPolicy Bypass -File ""{app}\Uninstall-CorelNest.ps1"""; Flags: runhidden
