[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$docker = Join-Path $root 'CorelNest.Dockers.dll'
$engine = Join-Path $root 'Engine\CorelNest.Export.exe'
$dockerGuid = '{E4B80B0C-42F1-4C2A-9F62-4D9A0F8C8B31}'
$dockerClass = 'CorelNest.Dockers.CorelNestPanel'
$progId = 'CorelDRAW.Application.27'

if (-not (Test-Path $docker)) { throw "Docker assembly tidak ditemukan: $docker" }
if (-not (Test-Path $engine)) { throw "Mesin nesting tidak ditemukan: $engine" }
try { $app = [Runtime.InteropServices.Marshal]::GetActiveObject($progId) }
catch {
    try { $app = New-Object -ComObject $progId }
    catch { throw 'CorelDRAW Technical Suite 27 tidak ditemukan. Pastikan aplikasi sudah terpasang.' }
}
$app.Visible = $true
try { $app.FrameWork.AddDocker($dockerGuid, $dockerClass, $docker) }
catch {
    # If this Docker is already registered in the current session, show the existing instance.
    try { $app.FrameWork.ShowDocker($dockerGuid); Write-Host 'CorelNest Pro Docker sudah terdaftar; panel ditampilkan kembali.' -ForegroundColor Green; exit 0 }
    catch { throw }
}
$app.FrameWork.ShowDocker($dockerGuid)
Write-Host 'CorelNest Pro berhasil dimuat pada sesi CorelDRAW ini.' -ForegroundColor Green
Write-Host 'Jika panel belum tampak, periksa menu Window > Dockers.'
