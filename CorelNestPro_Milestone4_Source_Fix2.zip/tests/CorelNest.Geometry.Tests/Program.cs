using CorelNest.Geometry.Algorithms;
using CorelNest.Geometry.Models;

static void Assert(bool condition,string message){if(!condition)throw new Exception("FAIL: "+message);Console.WriteLine("PASS: "+message);}
static Polygon2D Rect(double x,double y,double w,double h)=>new(new[]{new Point2(x,y),new Point2(x+w,y),new Point2(x+w,y+h),new Point2(x,y+h)});
var a=Rect(0,0,10,10); var b=Rect(5,5,10,10); var c=Rect(20,20,2,2);
Assert(Geometry2D.PolygonsOverlap(a,b),"overlap detection");
Assert(!Geometry2D.PolygonsOverlap(a,c),"separated polygons");
Assert(Geometry2D.IsInside(Rect(2,2,2,2),a),"part inside part containment");
var nfp=ConvexNfp.ComputeForbiddenRegion(a,Rect(0,0,2,2));
Assert(nfp.Bounds.Width==12 && nfp.Bounds.Height==12,"convex NFP forbidden region dimensions");
var result=new NestingEngine().Nest(new[]{new NestingPart("A",Rect(0,0,30,20),2)},new NestingOptions(100,60,2,2,90,true));
Assert(result.Placed.Count==2,"two parts placed");
var measuredGap=Geometry2D.MinimumDistance(result.Placed[0].Shape,result.Placed[1].Shape);
Console.WriteLine($"Measured clearance: {measuredGap:F6}");
Console.WriteLine($"Part 1 bounds: {result.Placed[0].Shape.Bounds}");
Console.WriteLine($"Part 2 bounds: {result.Placed[1].Shape.Bounds}");
Assert(measuredGap>=2-1e-7,"part clearance respected");
Console.WriteLine($"Utilization: {result.UtilizationPercent:F2}%");

// Milestone 2: adaptive curve flattening is independent of Corel COM and can be tested offline.
var arc = CorelNest.Geometry.Geometry.CurveFlattener.Flatten(
    t => new Point2(10 * t, 10 * t * t), 0.05);
Assert(arc.Count > 2, "adaptive curve flattening subdivides curved segment");
Assert(Point2.Distance(arc[0], new Point2(0, 0)) < 1e-9 &&
       Point2.Distance(arc[^1], new Point2(10, 10)) < 1e-9,
       "adaptive curve flattening preserves endpoints");


// Milestone 3: compound contours (outer boundary + void rings + nested islands).
var outer = Rect(0, 0, 100, 100);
var hole = Rect(20, 20, 60, 60);
var island = Rect(40, 40, 10, 10);
var topology = CorelNest.Geometry.Topology.ContourTopologyClassifier.Classify(new[] { outer, hole, island });
Assert(topology[0].Role == CorelNest.Geometry.Topology.ContourRole.Outer && topology[0].Depth == 0, "compound contour outer classification");
Assert(topology[1].Role == CorelNest.Geometry.Topology.ContourRole.Hole && topology[1].Depth == 1, "compound contour hole classification");
Assert(topology[2].Role == CorelNest.Geometry.Topology.ContourRole.Island && topology[2].Depth == 2, "compound contour island classification");
var donut = new PolygonRegion2D(outer, new[] { hole });
Assert(Math.Abs(donut.MaterialArea - 6400) < 1e-7, "compound region material area excludes hole");
Assert(CompoundGeometry2D.IsPolygonInsideVoid(Rect(25, 25, 10, 10), donut, 2), "part fits inside hole with clearance");
Assert(!CompoundGeometry2D.IsPolygonInsideVoid(Rect(19, 25, 10, 10), donut, 2), "part crossing hole boundary is rejected");
Assert(CompoundGeometry2D.IntersectsMaterial(Rect(5, 5, 10, 10), donut), "solid material collision outside hole");
Assert(!CompoundGeometry2D.IntersectsMaterial(Rect(25, 25, 10, 10), donut), "void area does not count as material collision");
var solidRegion = new PolygonRegion2D(Rect(0, 0, 30, 20));
Assert(!CompoundGeometry2D.IntersectsMaterial(Rect(32, 0, 10, 10), solidRegion, 2), "exact requested clearance is accepted");
Assert(CompoundGeometry2D.IntersectsMaterial(Rect(31.99, 0, 10, 10), solidRegion, 2), "clearance smaller than requested is rejected");
var donutNest = new NestingEngine().Nest(
    new[] { new NestingPart("DONUT", outer, 1, false, new[] { hole }), new NestingPart("INSERT", Rect(0, 0, 10, 10), 1, false) },
    new NestingOptions(120, 120, 2, 2, 15, true));
Assert(donutNest.Placed.Count == 2, "nesting places a part inside a compound part hole");
var insertedPart = donutNest.Placed.SingleOrDefault(p => p.Id == "INSERT");
var placedDonut = donutNest.Placed.Single(p => p.Id == "DONUT");
Assert(insertedPart is not null &&
       placedDonut.Holes!.Any(h => h.Bounds.Contains(insertedPart.Shape.Bounds)),
       "insert is located within host hole");
Assert(insertedPart is not null &&
       CompoundGeometry2D.IsPolygonInsideVoid(
           insertedPart.Shape,
           new PolygonRegion2D(placedDonut.Shape, placedDonut.Holes),
           2),
       "insert maintains requested clearance inside host hole");
