using System.Text.Json;
using System.Text.Json.Serialization;
using CorelNest.CorelBridge;
using CorelNest.Geometry.Algorithms;
using CorelNest.Geometry.Models;
using CorelNest.Geometry.Topology;

internal static class Program
{
    [STAThread]
    private static int Main(string[] args)
    {
        try
        {
            if (args.Length == 0 || args.Contains("--help", StringComparer.OrdinalIgnoreCase))
            {
                PrintHelp();
                return 0;
            }

            string? nestOutput = GetOption(args, "--nest-selection");
            string? exportOutput = GetOption(args, "--export-selection");
            if (string.IsNullOrWhiteSpace(nestOutput) && string.IsNullOrWhiteSpace(exportOutput))
                throw new ArgumentException("Gunakan --export-selection <file.json> atau --nest-selection <file.csv>.");

            string progId = GetOption(args, "--prog-id") ?? "CorelDRAW.Application.27";
            double tolerance = Number(args, "--tolerance-mm", 0.20);
            var reader = new CorelSelectionReader(progId);
            var selection = reader.ReadSelection(tolerance);

            if (!string.IsNullOrWhiteSpace(nestOutput))
            {
                RunNesting(selection, nestOutput, args);
                return 0;
            }

            WriteJson(exportOutput!, selection);
            Console.WriteLine($"Export berhasil: {Path.GetFullPath(exportOutput!)}");
            Console.WriteLine($"Objek terbaca: {selection.Objects.Count}");
            Console.WriteLine($"Kontur: {selection.Objects.Sum(o => o.Contours.Count)}");
            Console.WriteLine($"Toleransi kurva: {selection.CurveToleranceMm.ToString("0.###", System.Globalization.CultureInfo.InvariantCulture)} mm");
            foreach (var warning in selection.Warnings) Console.WriteLine("WARNING: " + warning);
            return 0;
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine("CorelNest Export gagal: " + ex.Message);
            return 2;
        }
    }

    private static void RunNesting(CorelSelectionExport selection, string output, string[] args)
    {
        double sheetW = Number(args, "--sheet-width-mm", 1200);
        double sheetH = Number(args, "--sheet-height-mm", 2400);
        double gap = Number(args, "--part-gap-mm", 3);
        double margin = Number(args, "--border-gap-mm", 10);
        double rotation = Number(args, "--rotation-step-deg", 15);
        var parts = new List<NestingPart>();
        var warnings = new List<string>(selection.Warnings);

        foreach (var item in selection.Objects)
        {
            try
            {
                var rings = item.Contours.Where(c => c.Closed)
                    .Select(c => new Polygon2D(c.Points.Select(p => new Point2(p.X, p.Y))))
                    .ToArray();
                var regions = ContourTopologyClassifier.BuildRegions(rings);
                if (regions.Count != 1)
                {
                    warnings.Add($"{item.Name}: ditemukan {regions.Count} area terpisah/island. Untuk tahap ini objek dilewati agar artwork tidak terduplikasi atau hilang.");
                    continue;
                }
                var region = regions[0];
                parts.Add(new NestingPart(item.SelectionIndex.ToString(System.Globalization.CultureInfo.InvariantCulture),
                    region.Outer, 1, true, region.Holes));
            }
            catch (Exception ex)
            {
                warnings.Add($"{item.Name}: gagal membangun region nesting: {ex.Message}");
            }
        }

        if (parts.Count == 0) throw new InvalidOperationException("Tidak ada objek yang memenuhi syarat nesting. Pastikan objek memiliki satu outline tertutup utama.");
        var options = new NestingOptions(sheetW, sheetH, gap, margin, rotation, true);
        var result = new NestingEngine().Nest(parts, options);
        string fullPath = Path.GetFullPath(output);
        Directory.CreateDirectory(Path.GetDirectoryName(fullPath)!);
        var lines = new List<string> { "SelectionIndex,CopyIndex,Xmm,Ymm,RotationDegrees,WidthMm,HeightMm" };
        foreach (var placed in result.Placed.OrderBy(p => int.Parse(p.Id, System.Globalization.CultureInfo.InvariantCulture)).ThenBy(p => p.CopyIndex))
        {
            var b = placed.Shape.Bounds;
            lines.Add(string.Join(",", placed.Id, placed.CopyIndex.ToString(System.Globalization.CultureInfo.InvariantCulture),
                F(b.MinX), F(b.MinY), F(placed.RotationDegrees), F(b.Width), F(b.Height)));
        }
        File.WriteAllLines(fullPath, lines, new System.Text.UTF8Encoding(false));
        Console.WriteLine($"NEST_OK={result.Placed.Count}");
        Console.WriteLine($"NEST_UNPLACED={result.Unplaced.Count}");
        Console.WriteLine($"NEST_UTILIZATION={result.UtilizationPercent.ToString("0.00", System.Globalization.CultureInfo.InvariantCulture)}");
        Console.WriteLine($"NEST_OUTPUT={fullPath}");
        foreach (var id in result.Unplaced) warnings.Add($"Tidak muat di lembar: selection #{id}.");
        foreach (var warning in warnings) Console.WriteLine("WARNING: " + warning);
        if (result.Placed.Count == 0) throw new InvalidOperationException("Tidak ada objek yang berhasil ditempatkan.");
    }

    private static string F(double value) => value.ToString("0.########", System.Globalization.CultureInfo.InvariantCulture);

    private static double Number(string[] args, string name, double fallback) =>
        double.TryParse(GetOption(args, name), System.Globalization.NumberStyles.Float,
            System.Globalization.CultureInfo.InvariantCulture, out var value) ? value : fallback;

    private static void WriteJson(string output, CorelSelectionExport result)
    {
        var json = JsonSerializer.Serialize(result, new JsonSerializerOptions
        {
            WriteIndented = true,
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
        });
        string fullPath = Path.GetFullPath(output);
        Directory.CreateDirectory(Path.GetDirectoryName(fullPath)!);
        string tempPath = fullPath + ".tmp";
        File.WriteAllText(tempPath, json);
        File.Move(tempPath, fullPath, true);
    }

    private static string? GetOption(string[] args, string name)
    {
        for (int i = 0; i < args.Length - 1; i++)
            if (string.Equals(args[i], name, StringComparison.OrdinalIgnoreCase)) return args[i + 1];
        return null;
    }

    private static void PrintHelp()
    {
        Console.WriteLine("CorelNest Export + Nest Runner - Milestone 4");
        Console.WriteLine("Pastikan CorelDRAW terbuka dan objek sudah dipilih.");
        Console.WriteLine("  --export-selection <file.json> [--tolerance-mm 0.20]");
        Console.WriteLine("  --nest-selection <file.csv> --sheet-width-mm 1200 --sheet-height-mm 2400");
        Console.WriteLine("    [--part-gap-mm 3] [--border-gap-mm 10] [--rotation-step-deg 15]");
        Console.WriteLine("Catatan: pembacaan geometri memakai duplikat sementara; artwork asli tidak diubah.");
    }
}
