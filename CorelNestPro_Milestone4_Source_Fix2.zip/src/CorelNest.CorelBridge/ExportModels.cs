using CorelNest.Geometry.Models;

namespace CorelNest.CorelBridge;

public sealed record CorelSelectionExport(
    string Format,
    string CoordinateUnit,
    string CoordinateConvention,
    string DocumentName,
    DateTimeOffset ExportedAt,
    double CurveToleranceMm,
    IReadOnlyList<CorelObjectExport> Objects,
    IReadOnlyList<string> Warnings);

public sealed record CorelObjectExport(
    int SelectionIndex,
    string Name,
    string SourceType,
    BoundsExport OriginalBoundsMm,
    double LocalWidthMm,
    double LocalHeightMm,
    IReadOnlyList<CorelContourExport> Contours);

public sealed record BoundsExport(double MinX, double MinY, double MaxX, double MaxY);

public sealed record CorelContourExport(
    bool Closed,
    double SignedAreaMm2,
    string Winding,
    IReadOnlyList<PointExport> Points);

public sealed record PointExport(double X, double Y);
