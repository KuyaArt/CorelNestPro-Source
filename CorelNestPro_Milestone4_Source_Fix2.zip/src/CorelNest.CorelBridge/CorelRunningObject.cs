using System.Runtime.InteropServices;

namespace CorelNest.CorelBridge;

internal static class CorelRunningObject
{
    [DllImport("ole32.dll", CharSet = CharSet.Unicode, PreserveSig = true)]
    private static extern int CLSIDFromProgID(string progId, out Guid clsid);

    [DllImport("oleaut32.dll", PreserveSig = true)]
    private static extern int GetActiveObject(ref Guid clsid, IntPtr reserved,
        [MarshalAs(UnmanagedType.IUnknown)] out object? runningObject);

    public static object Attach(string progId)
    {
        if (!OperatingSystem.IsWindows())
            throw new PlatformNotSupportedException("CorelDRAW COM automation is available only on Windows.");

        int hr = CLSIDFromProgID(progId, out var clsid);
        Marshal.ThrowExceptionForHR(hr);
        hr = GetActiveObject(ref clsid, IntPtr.Zero, out var instance);
        if (hr < 0 || instance is null)
            throw new InvalidOperationException(
                $"Tidak menemukan CorelDRAW yang sedang berjalan dengan ProgID '{progId}'. " +
                "Buka CorelDRAW Technical Suite 27 dan buka dokumen terlebih dahulu.");
        return instance;
    }
}
