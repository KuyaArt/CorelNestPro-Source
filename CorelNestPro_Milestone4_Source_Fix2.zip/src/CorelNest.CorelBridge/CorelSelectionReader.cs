using System.Runtime.InteropServices;
using CorelNest.Geometry.Geometry;
using CorelNest.Geometry.Models;

namespace CorelNest.CorelBridge;

/// <summary>
/// Late-bound adapter for CorelDRAW 27. It duplicates each selected shape,
/// converts the duplicate to curves, reads closed subpaths and deletes the
/// temporary duplicate. Original artwork is not converted or moved.
/// </summary>
public sealed class CorelSelectionReader
{
    private const int CdrMillimeter = 3;
    private readonly string _progId;

    public CorelSelectionReader(string progId = "CorelDRAW.Application.27") => _progId = progId;

    public CorelSelectionExport ReadSelection(double curveToleranceMm = 0.20)
    {
        if (!double.IsFinite(curveToleranceMm) || curveToleranceMm <= 0 || curveToleranceMm > 5)
            throw new ArgumentOutOfRangeException(nameof(curveToleranceMm), "Gunakan toleransi 0.01–5 mm.");

        dynamic app = CorelRunningObject.Attach(_progId);
        dynamic document = app.ActiveDocument;
        dynamic selection = app.ActiveSelectionRange;
        int count = Convert.ToInt32(selection.Count);
        if (count == 0)
            throw new InvalidOperationException("Pilih minimal satu objek tertutup di CorelDRAW terlebih dahulu.");

        int sourceUnit = Convert.ToInt32(document.Unit);
        string documentName = SafeString(() => (string)document.Name, "(dokumen tanpa nama)");
        var objects = new List<CorelObjectExport>();
        var warnings = new List<string>();

        for (int i = 1; i <= count; i++)
        {
            object? duplicateObject = null;
            try
            {
                dynamic sourceShape = selection.Item(i);
                string name = SafeString(() => (string)sourceShape.Name, $"Shape_{i}");
                string sourceType = SafeString(() => Convert.ToString(sourceShape.Type) ?? "Unknown", "Unknown");

                // Work on a temporary duplicate so source shapes remain untouched.
                dynamic duplicate = sourceShape.Duplicate(0.0, 0.0);
                duplicateObject = duplicate;
                duplicate.ConvertToCurves();
                dynamic curve = duplicate.Curve;
                dynamic subPaths = curve.SubPaths;
                int subPathCount = Convert.ToInt32(subPaths.Count);
                var contoursRaw = new List<(bool Closed, List<Point2> Points)>();

                for (int s = 1; s <= subPathCount; s++)
                {
                    dynamic subPath = subPaths.Item(s);
                    bool closed = Convert.ToBoolean(subPath.Closed);
                    if (!closed)
                    {
                        warnings.Add($"{name}: subpath {s} terbuka dan tidak dimasukkan ke outline nesting.");
                        continue;
                    }

                    dynamic segments = subPath.Segments;
                    int segmentCount = Convert.ToInt32(segments.Count);
                    if (segmentCount < 1)
                    {
                        warnings.Add($"{name}: subpath {s} tidak memiliki segmen.");
                        continue;
                    }

                    var ring = new List<Point2>();
                    for (int segIndex = 1; segIndex <= segmentCount; segIndex++)
                    {
                        dynamic segment = segments.Item(segIndex);
                        IReadOnlyList<Point2> flattened = CurveFlattener.Flatten(t =>
                        {
                            dynamic point = segment.GetPointAt(t);
                            double x = Convert.ToDouble(point.x);
                            double y = Convert.ToDouble(point.y);
                            return new Point2(ToMillimeters(app, x, sourceUnit), ToMillimeters(app, y, sourceUnit));
                        }, curveToleranceMm);

                        // The last point of a segment is the first point of the next segment.
                        int take = segIndex == segmentCount ? flattened.Count - 1 : flattened.Count - 1;
                        for (int p = 0; p < take; p++)
                        {
                            var candidate = flattened[p];
                            if (ring.Count == 0 || Point2.Distance(ring[^1], candidate) > 1e-7)
                                ring.Add(candidate);
                        }
                    }

                    if (ring.Count > 1 && Point2.Distance(ring[0], ring[^1]) <= 1e-7)
                        ring.RemoveAt(ring.Count - 1);
                    if (ring.Count < 3)
                    {
                        warnings.Add($"{name}: subpath {s} menghasilkan kurang dari tiga titik.");
                        continue;
                    }
                    contoursRaw.Add((true, ring));
                }

                if (contoursRaw.Count == 0)
                {
                    warnings.Add($"{name}: tidak ditemukan kontur tertutup yang dapat dipakai.");
                    continue;
                }

                var allPoints = contoursRaw.SelectMany(c => c.Points).ToList();
                double minX = allPoints.Min(p => p.X), minY = allPoints.Min(p => p.Y);
                double maxX = allPoints.Max(p => p.X), maxY = allPoints.Max(p => p.Y);
                var contours = contoursRaw.Select(c =>
                {
                    var local = c.Points.Select(p => new Point2(p.X - minX, p.Y - minY)).ToList();
                    double area = SignedArea(local);
                    return new CorelContourExport(c.Closed, area,
                        area >= 0 ? "CounterClockwise" : "Clockwise",
                        local.Select(p => new PointExport(p.X, p.Y)).ToArray());
                }).ToArray();

                objects.Add(new CorelObjectExport(i, name, sourceType,
                    new BoundsExport(minX, minY, maxX, maxY), maxX - minX, maxY - minY, contours));
            }
            catch (Exception ex)
            {
                warnings.Add($"Objek seleksi #{i} gagal dibaca: {ex.Message}");
            }
            finally
            {
                if (duplicateObject is not null)
                {
                    try { ((dynamic)duplicateObject).Delete(); }
                    catch (Exception ex) { warnings.Add($"Peringatan: duplikat sementara #{i} gagal dihapus: {ex.Message}"); }
                    if (Marshal.IsComObject(duplicateObject))
                    {
                        try { Marshal.FinalReleaseComObject(duplicateObject); } catch { }
                    }
                }
            }
        }

        if (objects.Count == 0)
            throw new InvalidOperationException("Tidak ada objek yang berhasil diekspor. Pastikan pilihan berisi shape dengan kontur tertutup.");

        return new CorelSelectionExport(
            "CorelNest.SelectionGeometry.v1", "mm",
            "X-right,Y-up; each contour is localized to its object's lower-left bounds",
            documentName, DateTimeOffset.Now, curveToleranceMm, objects, warnings);
    }

    private static double ToMillimeters(dynamic app, double value, int sourceUnit) =>
        Convert.ToDouble(app.ConvertUnits(value, sourceUnit, CdrMillimeter));

    private static double SignedArea(IReadOnlyList<Point2> points)
    {
        double sum = 0;
        for (int i = 0; i < points.Count; i++)
        {
            var a = points[i]; var b = points[(i + 1) % points.Count];
            sum += a.X * b.Y - b.X * a.Y;
        }
        return sum / 2.0;
    }

    private static string SafeString(Func<string> read, string fallback)
    {
        try { return read(); } catch { return fallback; }
    }
}
