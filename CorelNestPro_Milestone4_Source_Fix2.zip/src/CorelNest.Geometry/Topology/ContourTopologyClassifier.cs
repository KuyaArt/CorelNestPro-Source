using CorelNest.Geometry.Algorithms;
using CorelNest.Geometry.Models;

namespace CorelNest.Geometry.Topology;

public enum ContourRole { Outer, Hole, Island }

/// <summary>Containment-tree classifier. Depth parity determines filled/void/island roles.</summary>
public sealed record ClassifiedContour(Polygon2D Ring, ContourRole Role, int Depth, int? ParentIndex);

public static class ContourTopologyClassifier
{
    public static IReadOnlyList<ClassifiedContour> Classify(IReadOnlyList<Polygon2D> rings)
    {
        ArgumentNullException.ThrowIfNull(rings);
        if (rings.Count == 0) return Array.Empty<ClassifiedContour>();

        var parents = new int?[rings.Count];
        var depths = new int[rings.Count];
        for (int i = 0; i < rings.Count; i++)
        {
            double parentArea = double.PositiveInfinity;
            for (int j = 0; j < rings.Count; j++)
            {
                if (i == j || rings[j].Area <= rings[i].Area + 1e-9) continue;
                if (!Geometry2D.IsInside(rings[i], rings[j])) continue;
                if (rings[j].Area < parentArea) { parentArea = rings[j].Area; parents[i] = j; }
            }
        }

        for (int i = 0; i < rings.Count; i++)
        {
            var seen = new HashSet<int>();
            int? p = parents[i];
            while (p.HasValue)
            {
                if (!seen.Add(p.Value)) throw new InvalidOperationException("Contour containment cycle detected.");
                depths[i]++;
                p = parents[p.Value];
            }
        }

        return Enumerable.Range(0, rings.Count)
            .Select(i => new ClassifiedContour(rings[i], depths[i] % 2 == 0 ? (depths[i] == 0 ? ContourRole.Outer : ContourRole.Island) : ContourRole.Hole, depths[i], parents[i]))
            .ToArray();
    }

    public static IReadOnlyList<PolygonRegion2D> BuildRegions(IReadOnlyList<Polygon2D> rings)
    {
        var classified = Classify(rings);
        var output = new List<PolygonRegion2D>();
        for (int i = 0; i < classified.Count; i++)
        {
            var item = classified[i];
            if (item.Role is not (ContourRole.Outer or ContourRole.Island)) continue;
            var holes = classified.Where(x => x.Role == ContourRole.Hole && x.ParentIndex == i).Select(x => x.Ring);
            output.Add(new PolygonRegion2D(item.Ring, holes));
        }
        return output;
    }
}
