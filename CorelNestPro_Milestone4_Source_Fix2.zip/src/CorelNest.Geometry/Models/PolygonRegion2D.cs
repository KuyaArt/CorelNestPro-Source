namespace CorelNest.Geometry.Models;

/// <summary>A filled polygon region: one outer boundary and zero or more void rings.</summary>
public sealed class PolygonRegion2D
{
    public Polygon2D Outer { get; }
    public IReadOnlyList<Polygon2D> Holes { get; }
    public double MaterialArea => Math.Max(0, Outer.Area - Holes.Sum(h => h.Area));
    public Bounds2 Bounds => Outer.Bounds;

    public PolygonRegion2D(Polygon2D outer, IEnumerable<Polygon2D>? holes = null)
    {
        Outer = outer ?? throw new ArgumentNullException(nameof(outer));
        var list = (holes ?? Array.Empty<Polygon2D>()).ToList();
        foreach (var hole in list)
        {
            if (!CorelNest.Geometry.Algorithms.Geometry2D.IsInside(hole, outer))
                throw new ArgumentException("Every hole must lie completely inside the outer boundary.", nameof(holes));
        }
        for (int i = 0; i < list.Count; i++)
            for (int j = i + 1; j < list.Count; j++)
                if (CorelNest.Geometry.Algorithms.Geometry2D.PolygonsOverlap(list[i], list[j]))
                    throw new ArgumentException("Hole rings cannot overlap or contain one another.", nameof(holes));
        Holes = list.AsReadOnly();
    }
}
