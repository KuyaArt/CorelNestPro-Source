namespace CorelNest.Geometry.Models;

public readonly record struct Bounds2(double MinX, double MinY, double MaxX, double MaxY)
{
    public double Width => MaxX - MinX;
    public double Height => MaxY - MinY;
    public bool Contains(Point2 p, double eps = 1e-9) => p.X >= MinX - eps && p.X <= MaxX + eps && p.Y >= MinY - eps && p.Y <= MaxY + eps;
    public bool Contains(Bounds2 b, double eps = 1e-9) => b.MinX >= MinX - eps && b.MinY >= MinY - eps && b.MaxX <= MaxX + eps && b.MaxY <= MaxY + eps;
    public bool Intersects(Bounds2 b, double eps = 1e-9) => !(MaxX < b.MinX - eps || b.MaxX < MinX - eps || MaxY < b.MinY - eps || b.MaxY < MinY - eps);
    public Bounds2 Expand(double d) => new(MinX - d, MinY - d, MaxX + d, MaxY + d);
}
