namespace CorelNest.Geometry.Models;

public readonly record struct Point2(double X, double Y)
{
    public static Point2 operator +(Point2 a, Point2 b) => new(a.X + b.X, a.Y + b.Y);
    public static Point2 operator -(Point2 a, Point2 b) => new(a.X - b.X, a.Y - b.Y);
    public static Point2 operator *(Point2 p, double s) => new(p.X * s, p.Y * s);
    public double Length => Math.Sqrt(X * X + Y * Y);
    public static double Distance(Point2 a, Point2 b) => (a - b).Length;
}
