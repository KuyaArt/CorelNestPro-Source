namespace CorelNest.Geometry.Models;

/// <summary>Simple closed polygon ring. The first point is not repeated at the end.</summary>
public sealed class Polygon2D
{
    private readonly Point2[] _vertices;
    public IReadOnlyList<Point2> Vertices => _vertices;
    public int Count => _vertices.Length;

    public Polygon2D(IEnumerable<Point2> vertices)
    {
        ArgumentNullException.ThrowIfNull(vertices);
        var list = vertices.ToList();
        if (list.Count > 1 && Point2.Distance(list[0], list[^1]) < 1e-10) list.RemoveAt(list.Count - 1);
        if (list.Count < 3) throw new ArgumentException("Polygon requires at least three distinct vertices.", nameof(vertices));
        if (list.Any(p => !double.IsFinite(p.X) || !double.IsFinite(p.Y))) throw new ArgumentException("Coordinates must be finite.", nameof(vertices));
        _vertices = list.ToArray();
    }

    public double SignedArea
    {
        get
        {
            double sum = 0;
            for (int i = 0; i < Count; i++)
            {
                var a = _vertices[i]; var b = _vertices[(i + 1) % Count];
                sum += a.X * b.Y - b.X * a.Y;
            }
            return sum / 2.0;
        }
    }
    public double Area => Math.Abs(SignedArea);
    public Bounds2 Bounds => new(_vertices.Min(p => p.X), _vertices.Min(p => p.Y), _vertices.Max(p => p.X), _vertices.Max(p => p.Y));
    public Polygon2D Translate(Point2 delta) => new(_vertices.Select(p => p + delta));
    public Polygon2D Rotate(double degrees, Point2 origin)
    {
        double r = degrees * Math.PI / 180.0, c = Math.Cos(r), s = Math.Sin(r);
        return new(_vertices.Select(p => { double x = p.X - origin.X, y = p.Y - origin.Y; return new Point2(origin.X + x * c - y * s, origin.Y + x * s + y * c); }));
    }
    public Polygon2D RotateAroundCentroid(double degrees)
    {
        double a = SignedArea, cx = 0, cy = 0;
        for (int i = 0; i < Count; i++)
        {
            var p = _vertices[i]; var q = _vertices[(i + 1) % Count];
            double cross = p.X * q.Y - q.X * p.Y;
            cx += (p.X + q.X) * cross; cy += (p.Y + q.Y) * cross;
        }
        var center = Math.Abs(a) < 1e-12 ? new Point2(_vertices.Average(p => p.X), _vertices.Average(p => p.Y)) : new Point2(cx / (6 * a), cy / (6 * a));
        return Rotate(degrees, center);
    }
    public Polygon2D NormalizeToOrigin()
    {
        var b = Bounds;
        return Translate(new Point2(-b.MinX, -b.MinY));
    }
}
