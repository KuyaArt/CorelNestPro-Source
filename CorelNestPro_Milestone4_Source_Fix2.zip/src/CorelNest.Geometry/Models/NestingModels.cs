namespace CorelNest.Geometry.Models;

public sealed record NestingPart(string Id, Polygon2D Shape, int Quantity = 1, bool AllowRotation = true, IReadOnlyList<Polygon2D>? Holes = null);
public sealed record PlacedPart(string Id, int CopyIndex, Polygon2D Shape, double RotationDegrees, IReadOnlyList<Polygon2D>? Holes = null);
public sealed record NestingOptions(double SheetWidth, double SheetHeight, double PartGap, double BorderGap, double RotationStepDegrees = 15, bool AllowPartInsidePart = true, int MaxCandidatesPerPart = 25000)
{
    public void Validate()
    {
        if (SheetWidth<=0||SheetHeight<=0) throw new ArgumentOutOfRangeException(nameof(SheetWidth),"Sheet dimensions must be positive.");
        if (PartGap<0||BorderGap<0) throw new ArgumentOutOfRangeException(nameof(PartGap),"Gaps cannot be negative.");
        if (RotationStepDegrees<=0||RotationStepDegrees>360) throw new ArgumentOutOfRangeException(nameof(RotationStepDegrees));
        if (MaxCandidatesPerPart<1) throw new ArgumentOutOfRangeException(nameof(MaxCandidatesPerPart));
    }
}
public sealed record NestingResult(IReadOnlyList<PlacedPart> Placed, IReadOnlyList<string> Unplaced, double UtilizationPercent, int SheetsUsed = 1);
