using CorelNest.Geometry.Models;

namespace CorelNest.Geometry.Algorithms;

/// <summary>
/// Computes the forbidden translation region A (+) (-B) for convex simple polygons.
/// Translation t is forbidden when B+t overlaps A. Inputs must be convex.
/// </summary>
public static class ConvexNfp
{
    public static Polygon2D ComputeForbiddenRegion(Polygon2D fixedPart, Polygon2D movingPart)
    {
        if (!Geometry2D.IsConvex(fixedPart) || !Geometry2D.IsConvex(movingPart))
            throw new NotSupportedException("Convex NFP requires convex polygons. Decompose concave parts before calling this method.");
        var sums = from a in fixedPart.Vertices from b in movingPart.Vertices select new Point2(a.X-b.X,a.Y-b.Y);
        return Geometry2D.ConvexHull(sums);
    }
}
