using CorelNest.Geometry.Models;

namespace CorelNest.Geometry.Algorithms;

/// <summary>Material/void predicates for compound regions. Conservative on ambiguous crossings.</summary>
public static class CompoundGeometry2D
{
    public static bool IsPolygonInsideVoid(Polygon2D candidate, PolygonRegion2D container, double clearance = 0)
    {
        if (clearance < 0) throw new ArgumentOutOfRangeException(nameof(clearance));
        foreach (var hole in container.Holes)
        {
            if (!hole.Bounds.Contains(candidate.Bounds)) continue;
            if (candidate.Vertices.Any(p => Geometry2D.LocatePoint(hole, p) == PointLocation.Outside)) continue;
            if (BoundariesCross(candidate, hole)) continue;
            if (clearance > 0 && BoundaryDistance(candidate, hole) + 1e-8 < clearance) continue;
            return true;
        }
        return false;
    }

    public static bool IntersectsMaterial(Polygon2D candidate, PolygonRegion2D region, double clearance = 0)
    {
        if (clearance < 0) throw new ArgumentOutOfRangeException(nameof(clearance));
        if (!candidate.Bounds.Intersects(region.Bounds.Expand(clearance))) return false;
        if (IsPolygonInsideVoid(candidate, region, clearance)) return false;
        var outerDistance = Geometry2D.MinimumDistance(candidate, region.Outer);
        // A distance exactly equal to the requested clearance is valid.
        // With zero clearance, touching/overlap remains a collision.
        bool violatesClearance = clearance <= 1e-8
            ? outerDistance <= 1e-8
            : outerDistance < clearance - 1e-8;
        if (violatesClearance) return true;
        // A candidate crossing a void boundary touches material on at least one side.
        foreach (var hole in region.Holes)
            if (BoundariesCross(candidate, hole) || Geometry2D.LocatePoint(hole, candidate.Vertices[0]) == PointLocation.Inside || hole.Vertices.Any(p => Geometry2D.LocatePoint(candidate, p) == PointLocation.Inside))
                return true;
        return false;
    }

    private static double BoundaryDistance(Polygon2D a, Polygon2D b)
    {
        double min = double.PositiveInfinity;
        for (int i = 0; i < a.Count; i++)
            for (int j = 0; j < b.Count; j++)
                min = Math.Min(min, Geometry2D.DistanceSegments(a.Vertices[i], a.Vertices[(i + 1) % a.Count], b.Vertices[j], b.Vertices[(j + 1) % b.Count]));
        return min;
    }

    private static bool BoundariesCross(Polygon2D a, Polygon2D b)
    {
        for (int i = 0; i < a.Count; i++)
            for (int j = 0; j < b.Count; j++)
                if (Geometry2D.SegmentsIntersect(a.Vertices[i], a.Vertices[(i + 1) % a.Count], b.Vertices[j], b.Vertices[(j + 1) % b.Count]))
                    return true;
        return false;
    }
}
