using CorelNest.Geometry.Models;

namespace CorelNest.Geometry.Algorithms;

/// <summary>Deterministic single-sheet bottom-left heuristic. NFP vertices seed candidates;
/// every candidate is rechecked against exact polygon edges and requested clearance.</summary>
public sealed class NestingEngine
{
    public NestingResult Nest(IEnumerable<NestingPart> input, NestingOptions options, CancellationToken cancellationToken=default)
    {
        options.Validate();
        var parts=input.SelectMany(p=>Enumerable.Range(0,p.Quantity).Select(i=>(Part:p,Copy:i)))
            .OrderByDescending(x=>new PolygonRegion2D(x.Part.Shape, x.Part.Holes).MaterialArea).ToList();
        var placed=new List<PlacedPart>(); var unplaced=new List<string>();
        foreach(var item in parts)
        {
            cancellationToken.ThrowIfCancellationRequested();
            var best=FindBest(item.Part, item.Copy, placed, options, cancellationToken);
            if(best is null) unplaced.Add($"{item.Part.Id}#{item.Copy+1}"); else placed.Add(best);
        }
        double used=placed.Sum(p=>new PolygonRegion2D(p.Shape, p.Holes).MaterialArea), sheet=options.SheetWidth*options.SheetHeight;
        return new NestingResult(placed,unplaced,sheet<=0?0:used/sheet*100);
    }

    private static PlacedPart? FindBest(NestingPart part,int copy,List<PlacedPart> placed,NestingOptions o,CancellationToken ct)
    {
        var angles=part.AllowRotation?BuildAngles(o.RotationStepDegrees):new[]{0d};
        PlacedPart? best=null; double bestScore=double.PositiveInfinity; int examined=0;
        foreach(double angle in angles)
        {
            ct.ThrowIfCancellationRequested();
            var center = Centroid(part.Shape);
            var rawOuter = part.Shape.Rotate(angle, center);
            var shift = new Point2(-rawOuter.Bounds.MinX, -rawOuter.Bounds.MinY);
            var rotated = rawOuter.Translate(shift);
            var rotatedHoles = (part.Holes ?? Array.Empty<Polygon2D>())
                .Select(h => h.Rotate(angle, center).Translate(shift)).ToArray();
            var candidates=BuildCandidates(rotated,placed,o);
            foreach(var t in candidates)
            {
                if(++examined>o.MaxCandidatesPerPart) break;
                var candidate=rotated.Translate(t); var b=candidate.Bounds;
                if(b.MinX<o.BorderGap-1e-8||b.MinY<o.BorderGap-1e-8||b.MaxX>o.SheetWidth-o.BorderGap+1e-8||b.MaxY>o.SheetHeight-o.BorderGap+1e-8) continue;
                bool valid=true;
                var candidateRegion = new PolygonRegion2D(candidate, rotatedHoles.Select(h => h.Translate(t)));
                foreach(var p in placed)
                {
                    var placedRegion = new PolygonRegion2D(p.Shape, p.Holes);
                    bool collision;
                    if (!o.AllowPartInsidePart)
                        collision = Geometry2D.MinimumDistance(candidate, p.Shape) < o.PartGap - 1e-7;
                    else
                        collision = CompoundGeometry2D.IntersectsMaterial(candidate, placedRegion, o.PartGap) ||
                            (candidateRegion.Holes.Count > 0 && CompoundGeometry2D.IntersectsMaterial(p.Shape, candidateRegion, o.PartGap));
                    if (collision) { valid=false; break; }
                }
                if(!valid) continue;
                // Prefer a valid placement inside an existing void before using
                // fresh sheet area. Otherwise bottom-left scoring always chooses
                // the space beside the host, even when its hole can accept the part.
                bool fitsExistingHole = o.AllowPartInsidePart && placed.Any(p =>
                    CompoundGeometry2D.IsPolygonInsideVoid(
                        candidate,
                        new PolygonRegion2D(p.Shape, p.Holes),
                        o.PartGap));

                // Bottom-left score with a small compactness penalty. The large
                // deterministic bonus makes hole-filling take precedence over
                // ordinary sheet placements while retaining bottom-left ordering
                // among candidates with the same nesting status.
                double score=b.MinY*1_000_000+b.MinX*1000+(b.Width*b.Height)*0.001;
                if (fitsExistingHole) score -= 1_000_000_000_000_000d;
                if(score<bestScore){bestScore=score;best=new PlacedPart(part.Id,copy,candidate,angle,rotatedHoles.Select(h => h.Translate(t)).ToArray());}
            }
        }
        return best;
    }
    private static double[] BuildAngles(double step)
    {
        var angles = new List<double>();
        for (double angle = 0; angle < 360.0 - 1e-9; angle += step) angles.Add(angle);
        return angles.ToArray();
    }

    private static Point2 Centroid(Polygon2D polygon)
    {
        double area2 = 0, cx = 0, cy = 0;
        for (int i = 0; i < polygon.Count; i++)
        {
            var p = polygon.Vertices[i]; var q = polygon.Vertices[(i + 1) % polygon.Count];
            double cross = p.X * q.Y - q.X * p.Y;
            area2 += cross; cx += (p.X + q.X) * cross; cy += (p.Y + q.Y) * cross;
        }
        if (Math.Abs(area2) < 1e-12) return new Point2(polygon.Vertices.Average(p => p.X), polygon.Vertices.Average(p => p.Y));
        return new Point2(cx / (3 * area2), cy / (3 * area2));
    }
    private static List<Point2> BuildCandidates(Polygon2D moving,List<PlacedPart> placed,NestingOptions o)
    {
        var list=new List<Point2>{new(o.BorderGap,o.BorderGap)};
        foreach(var p in placed)
        {
            try
            {
                var forbidden=ConvexNfp.ComputeForbiddenRegion(p.Shape,moving);
                foreach(var v in forbidden.Vertices)
                {
                    list.Add(new Point2(v.X-o.PartGap,v.Y)); list.Add(new Point2(v.X+o.PartGap,v.Y));
                    list.Add(new Point2(v.X,v.Y-o.PartGap)); list.Add(new Point2(v.X,v.Y+o.PartGap));
                }
            }
            catch(NotSupportedException)
            {
                // Concave parts: vertex-to-vertex alignments are only candidate seeds;
                // exact edge-distance validation remains authoritative.
                foreach(var a in p.Shape.Vertices) foreach(var b in moving.Vertices) list.Add(new Point2(a.X-b.X,a.Y-b.Y));
            }
        }
        // Also try sheet-edge alignments and candidate positions at occupied bounds.
        foreach(var p in placed)
        {
            var b=p.Shape.Bounds;
            list.Add(new Point2(b.MaxX+o.PartGap,o.BorderGap));
            list.Add(new Point2(o.BorderGap,b.MaxY+o.PartGap));
            foreach (var hole in p.Holes ?? Array.Empty<Polygon2D>())
            {
                // Seed several interior translations. The centered seed avoids relying
                // on an exact-clearance corner, which can be sensitive to floating-point
                // noise after rotation/curve flattening.
                var hb = hole.Bounds;
                var mb = moving.Bounds;
                double freeX = hb.Width - mb.Width - 2 * o.PartGap;
                double freeY = hb.Height - mb.Height - 2 * o.PartGap;
                if (freeX >= -1e-8 && freeY >= -1e-8)
                {
                    list.Add(new Point2(hb.MinX + o.PartGap, hb.MinY + o.PartGap));
                    list.Add(new Point2(hb.MinX + o.PartGap + Math.Max(0, freeX), hb.MinY + o.PartGap));
                    list.Add(new Point2(hb.MinX + o.PartGap, hb.MinY + o.PartGap + Math.Max(0, freeY)));
                    list.Add(new Point2(hb.MinX + o.PartGap + Math.Max(0, freeX) / 2,
                                        hb.MinY + o.PartGap + Math.Max(0, freeY) / 2));
                }
            }
        }
        return list.Distinct().OrderBy(p=>p.Y).ThenBy(p=>p.X).ToList();
    }
}
