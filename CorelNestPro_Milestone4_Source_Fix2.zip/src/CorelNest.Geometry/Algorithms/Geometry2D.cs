using CorelNest.Geometry.Models;

namespace CorelNest.Geometry.Algorithms;

public enum PointLocation { Outside, Boundary, Inside }

public static class Geometry2D
{
    public static double Cross(Point2 a, Point2 b, Point2 c) => (b.X-a.X)*(c.Y-a.Y)-(b.Y-a.Y)*(c.X-a.X);
    public static PointLocation LocatePoint(Polygon2D polygon, Point2 p, double eps = 1e-9)
    {
        bool inside = false; var v = polygon.Vertices;
        for (int i=0,j=v.Count-1;i<v.Count;j=i++)
        {
            var a=v[j]; var b=v[i];
            if (Math.Abs(Cross(a,b,p)) <= eps && p.X >= Math.Min(a.X,b.X)-eps && p.X <= Math.Max(a.X,b.X)+eps && p.Y >= Math.Min(a.Y,b.Y)-eps && p.Y <= Math.Max(a.Y,b.Y)+eps) return PointLocation.Boundary;
            if (((a.Y > p.Y) != (b.Y > p.Y)) && p.X < (b.X-a.X)*(p.Y-a.Y)/(b.Y-a.Y)+a.X) inside = !inside;
        }
        return inside ? PointLocation.Inside : PointLocation.Outside;
    }
    public static bool SegmentsIntersect(Point2 a, Point2 b, Point2 c, Point2 d, double eps=1e-9)
    {
        double o1=Cross(a,b,c), o2=Cross(a,b,d), o3=Cross(c,d,a), o4=Cross(c,d,b);
        if (((o1>eps && o2 < -eps)||(o1 < -eps && o2>eps)) && ((o3>eps && o4 < -eps)||(o3 < -eps && o4>eps))) return true;
        return (Math.Abs(o1)<=eps && OnSegment(a,b,c,eps)) || (Math.Abs(o2)<=eps && OnSegment(a,b,d,eps)) || (Math.Abs(o3)<=eps && OnSegment(c,d,a,eps)) || (Math.Abs(o4)<=eps && OnSegment(c,d,b,eps));
    }
    private static bool OnSegment(Point2 a, Point2 b, Point2 p, double e) => p.X>=Math.Min(a.X,b.X)-e && p.X<=Math.Max(a.X,b.X)+e && p.Y>=Math.Min(a.Y,b.Y)-e && p.Y<=Math.Max(a.Y,b.Y)+e;
    public static double DistancePointSegment(Point2 p, Point2 a, Point2 b)
    {
        var ab=b-a; double den=ab.X*ab.X+ab.Y*ab.Y; if (den<=1e-20) return Point2.Distance(p,a);
        double t=Math.Clamp(((p.X-a.X)*ab.X+(p.Y-a.Y)*ab.Y)/den,0,1); return Point2.Distance(p,a+ab*t);
    }
    public static double DistanceSegments(Point2 a,Point2 b,Point2 c,Point2 d)
    {
        if (SegmentsIntersect(a,b,c,d)) return 0;
        return Math.Min(Math.Min(DistancePointSegment(a,c,d),DistancePointSegment(b,c,d)),Math.Min(DistancePointSegment(c,a,b),DistancePointSegment(d,a,b)));
    }
    public static double MinimumDistance(Polygon2D a, Polygon2D b)
    {
        if (a.Bounds.Intersects(b.Bounds))
        {
            if (PolygonsOverlap(a,b)) return 0;
        }
        double min=double.PositiveInfinity;
        for(int i=0;i<a.Count;i++) for(int j=0;j<b.Count;j++) min=Math.Min(min,DistanceSegments(a.Vertices[i],a.Vertices[(i+1)%a.Count],b.Vertices[j],b.Vertices[(j+1)%b.Count]));
        return min;
    }
    public static bool PolygonsOverlap(Polygon2D a, Polygon2D b, bool touchingIsOverlap=true)
    {
        if (!a.Bounds.Intersects(b.Bounds)) return false;
        for(int i=0;i<a.Count;i++) for(int j=0;j<b.Count;j++)
            if(SegmentsIntersect(a.Vertices[i],a.Vertices[(i+1)%a.Count],b.Vertices[j],b.Vertices[(j+1)%b.Count])) return touchingIsOverlap;
        return LocatePoint(a,b.Vertices[0])==PointLocation.Inside || LocatePoint(b,a.Vertices[0])==PointLocation.Inside;
    }
    public static bool IsInside(Polygon2D inner, Polygon2D outer)
    {
        if (!outer.Bounds.Contains(inner.Bounds)) return false;
        if (inner.Vertices.Any(p=>LocatePoint(outer,p)==PointLocation.Outside)) return false;
        for(int i=0;i<inner.Count;i++) for(int j=0;j<outer.Count;j++)
            if(SegmentsIntersect(inner.Vertices[i],inner.Vertices[(i+1)%inner.Count],outer.Vertices[j],outer.Vertices[(j+1)%outer.Count]) &&
               LocatePoint(outer,inner.Vertices[i])!=PointLocation.Boundary) return false;
        return true;
    }
    public static bool IsConvex(Polygon2D p)
    {
        int sign=0;
        for(int i=0;i<p.Count;i++) { double c=Cross(p.Vertices[i],p.Vertices[(i+1)%p.Count],p.Vertices[(i+2)%p.Count]); if(Math.Abs(c)<1e-10) continue; int s=Math.Sign(c); if(sign!=0&&s!=sign)return false; sign=s; }
        return sign!=0;
    }
    public static Polygon2D ConvexHull(IEnumerable<Point2> points)
    {
        var p=points.Distinct().OrderBy(x=>x.X).ThenBy(x=>x.Y).ToArray(); if(p.Length<3) throw new ArgumentException("At least three unique points required.");
        var lower=new List<Point2>(); foreach(var x in p){while(lower.Count>=2&&Cross(lower[^2],lower[^1],x)<=0)lower.RemoveAt(lower.Count-1);lower.Add(x);}
        var upper=new List<Point2>(); foreach(var x in p.Reverse()){while(upper.Count>=2&&Cross(upper[^2],upper[^1],x)<=0)upper.RemoveAt(upper.Count-1);upper.Add(x);}
        lower.RemoveAt(lower.Count-1);upper.RemoveAt(upper.Count-1);lower.AddRange(upper);return new Polygon2D(lower);
    }
}
