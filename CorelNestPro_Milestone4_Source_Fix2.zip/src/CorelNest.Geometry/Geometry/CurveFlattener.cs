namespace CorelNest.Geometry.Geometry;

using CorelNest.Geometry.Models;

/// <summary>
/// Adaptive parametric curve flattening. The supplied evaluator must return points
/// in the same linear coordinate system as the requested tolerance.
/// </summary>
public static class CurveFlattener
{
    public static IReadOnlyList<Point2> Flatten(
        Func<double, Point2> evaluate,
        double tolerance,
        int maxDepth = 16)
    {
        ArgumentNullException.ThrowIfNull(evaluate);
        if (!double.IsFinite(tolerance) || tolerance <= 0)
            throw new ArgumentOutOfRangeException(nameof(tolerance), "Tolerance must be a positive finite value.");
        if (maxDepth < 1 || maxDepth > 24)
            throw new ArgumentOutOfRangeException(nameof(maxDepth));

        var first = evaluate(0);
        var last = evaluate(1);
        var points = new List<Point2> { first };
        Subdivide(evaluate, 0, first, 1, last, tolerance, maxDepth, 0, points);
        return RemoveNearDuplicates(points, Math.Max(1e-10, tolerance * 1e-5));
    }

    private static void Subdivide(
        Func<double, Point2> evaluate,
        double t0, Point2 p0,
        double t1, Point2 p1,
        double tolerance, int maxDepth, int depth,
        List<Point2> output)
    {
        double span = t1 - t0;
        var q1 = evaluate(t0 + span * 0.25);
        var mid = evaluate(t0 + span * 0.50);
        var q3 = evaluate(t0 + span * 0.75);
        double deviation = Math.Max(DistanceToSegment(q1, p0, p1),
            Math.Max(DistanceToSegment(mid, p0, p1), DistanceToSegment(q3, p0, p1)));

        if (deviation <= tolerance || depth >= maxDepth)
        {
            output.Add(p1);
            return;
        }

        double tm = (t0 + t1) * 0.5;
        Subdivide(evaluate, t0, p0, tm, mid, tolerance, maxDepth, depth + 1, output);
        Subdivide(evaluate, tm, mid, t1, p1, tolerance, maxDepth, depth + 1, output);
    }

    private static double DistanceToSegment(Point2 p, Point2 a, Point2 b)
    {
        double dx = b.X - a.X, dy = b.Y - a.Y;
        double length2 = dx * dx + dy * dy;
        if (length2 <= 1e-24) return Point2.Distance(p, a);
        double t = Math.Clamp(((p.X - a.X) * dx + (p.Y - a.Y) * dy) / length2, 0, 1);
        var projection = new Point2(a.X + t * dx, a.Y + t * dy);
        return Point2.Distance(p, projection);
    }

    private static IReadOnlyList<Point2> RemoveNearDuplicates(List<Point2> points, double epsilon)
    {
        if (points.Count < 2) return points;
        var result = new List<Point2>(points.Count) { points[0] };
        foreach (var point in points.Skip(1))
            if (Point2.Distance(result[^1], point) > epsilon) result.Add(point);
        return result;
    }
}
