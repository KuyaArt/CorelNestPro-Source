[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$docker = Join-Path $root 'CorelNest.Dockers.dll'
$engine = Join-Path $root 'Engine\CorelNest.Export.exe'
$dockerGuid = '{E4B80B0C-42F1-4C2A-9F62-4D9A0F8C8B31}'
$dockerClass = 'CorelNest.Dockers.CorelNestPanel'
$progId = 'CorelDRAW.Application.27'
$log = Join-Path $env:TEMP 'CorelNestPro_Install.log'

function Write-Log([string]$Message) {
    $line = "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] $Message"
    Add-Content -LiteralPath $log -Value $line
    Write-Host $line
}

Remove-Item -LiteralPath $log -Force -ErrorAction SilentlyContinue
Write-Log 'Mulai registrasi CorelNest Pro (mode aman: tidak memanggil ShowDocker).'
if (-not (Test-Path -LiteralPath $docker)) { throw "Docker assembly tidak ditemukan: $docker" }
if (-not (Test-Path -LiteralPath $engine)) { throw "Mesin nesting tidak ditemukan: $engine" }

$app = $null
$framework = $null
try {
    try { $app = [Runtime.InteropServices.Marshal]::GetActiveObject($progId) }
    catch { throw 'CorelDRAW tidak ditemukan sebagai aplikasi yang sedang berjalan. Buka CorelDRAW terlebih dahulu.' }

    $framework = $app.FrameWork
    Write-Log "CorelDRAW aktif. Mendaftarkan Docker: $dockerClass"
    $framework.AddDocker($dockerGuid, $dockerClass, $docker)
    Write-Log 'AddDocker berhasil. ShowDocker sengaja tidak dipanggil untuk menghindari pemblokiran UI.'
    Write-Host ''
    Write-Host 'REGISTRASI BERHASIL.' -ForegroundColor Green
    Write-Host 'Sekarang buka Window > Dockers > CorelNest Pro secara manual.' -ForegroundColor Yellow
    Write-Host 'Jika UI tetap terkunci, tutup CorelDRAW sepenuhnya dan kirim file log.'
}
catch {
    Write-Log ('ERROR: ' + $_.Exception.ToString())
    throw
}
finally {
    if ($framework -and [Runtime.InteropServices.Marshal]::IsComObject($framework)) {
        try { [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($framework) } catch { }
    }
    if ($app -and [Runtime.InteropServices.Marshal]::IsComObject($app)) {
        try { [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($app) } catch { }
    }
    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()
    Write-Log 'Selesai; referensi COM dilepas.'
}
