@echo off
setlocal
cd /d "%~dp0"
echo ================================================
echo CorelNest Pro - Safe Docker Registration
echo ================================================
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-CorelNest.ps1"
set "RC=%ERRORLEVEL%"
echo.
echo Exit code: %RC%
echo Log: %TEMP%\CorelNestPro_Install.log
echo.
pause
exit /b %RC%
